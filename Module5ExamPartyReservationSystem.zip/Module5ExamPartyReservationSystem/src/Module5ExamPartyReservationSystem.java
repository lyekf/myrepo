
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/*
Description
You are a young and talented developer.

The first task you need to do is to implement a filtering module to a party reservation software.

First, to the party reservation Filter Module (TPRF Module for short) is passed a list with invitations.

Next the TPRF receives a sequence of commands that specify if you need to add or remove a given filter.

TPRF Commands are in the given format "{command;filter type;filter parameter}"

You can receive the following TPRF commands: "Add filter", "Remove filter" or "Print".

The possible TPRF filter types are: "Starts with", "Ends with", "Length" and "Contains".

All TPRF filter parameters will be a string (or an integer for the length filter).

The input will end with a "Print" command.

See the examples below:

Examples
Input								Output

Peter Michael Slav					Slav
Add filter;Starts with;P
Add filter;Starts with;M
Print


 
Input								Output

Peter Michael Bob					Michael
Add filter;Starts with;P			Bob
Add filter;Starts with;M
Remove filter;Starts with;M
Print
 
 
 
 
 

 */

public class Module5ExamPartyReservationSystem {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        if(input.length()==0){
            return;
        }
        List<String> names = Arrays.stream(input.split("\\s+")).collect(Collectors.toList());
        String line = scanner.nextLine();
        List<String> commandLines =  new ArrayList<>();
 
        while (!line.equals("Print")) {
            String[] lineParts = line.split(";");
            String commands = lineParts[0];
            String type = lineParts[1];
            String toCheck = lineParts[2];
 
            if (commands.equals("Add filter")) {
                commandLines.add(line);
            } else if (commands.equals("Remove filter")) {
                String commandToRemove = "Add filter;" + type + ";" + toCheck;
                commandLines.removeIf(s -> s.equals(commandToRemove));
            }
            line = scanner.nextLine();
        }
        
        for (String command : commandLines) {
            String[] lineParts = command.split(";");
            String type = lineParts[1];
            String toCheck = lineParts[2];
 
            Predicate<String> startsWith = name -> name.startsWith(toCheck);
            Predicate<String> endsWith = name -> name.endsWith(toCheck);
            Predicate<String> validLenght = name -> name.length() == Integer.parseInt(toCheck);
            Predicate<String> containsLetter = name -> name.contains(toCheck);
 
            switch (type) {
                case "Starts with":
                    names.removeIf(startsWith);
                    break;
                case "Ends with":
                    names.removeIf(endsWith);
                    break;
                case "Length":
                    names.removeIf(validLenght);
                    break;
                case "Contains":
                    names.removeIf(containsLetter);
                    break;
            }
        }
        String str = names.stream().collect(Collectors.joining(" ")).replaceAll("([\\[\\]])", "");
        System.out.println("string = " + str);
        
        System.out.println(names.stream().collect(Collectors.joining(" ")).toString().replaceAll("([\\[\\]])", ""));
    }
}
