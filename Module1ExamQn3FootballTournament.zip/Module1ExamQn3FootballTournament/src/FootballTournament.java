import java.util.Scanner;

/*
Description
Create a program that receives the name of a football team and displays statistics based on matches played this season.

The statistics should include the total points earned during the current season, detailed statistics on the outcome of the games played and thier win rate.

If for some reason the team has not played any games this season a special message should be displayed.

During the season, each team plays a certain number of football matches and for each match played points are awarded depending on the outcome.

There are three possible outcomes from a match:

W - the team wins and receives 3 points

D - a draw - the team gets 1 point

L - the team has lost the match and does not receive any points

Input
You will receive two lines of input:

The name of the football team - a string

The number of games, played during the season - an integer in range[0 ... 100]

For each game a separate line is given:

The result of the game - a character ("W", "D" or "L")

Output
Depending on whether the team has played any games or not in the current season, there are two possible outcomes:

If the team has not played a single match print out a single line in the following format:

"{team name} hasn't played any games during this season."

If the team has played at least one match, six lines should be displayed in the following format:

"{team name} has won {count points} points during this season."

"Total stats:"

"## W: {number of games won}"

"## D: {number draws}"

"## L: {number of games lost}"

"Win rate: {win rate(percentage)}%"

The percentage must be formatted to the second decimal place.



Example
Input											Output
Liverpool										Liverpool has won 19 points during this season.

10												Total stats:

W												## W: 5

D												## D: 4

D												## L: 1

W												Win rate: 50.00%

L

W

D

D

W

W

HINT #1
Determine the total points for the team. Each win is 3 points, a draw is 1 and no points are awarded for a loss.

HINT #2
Keep track of each win, draw and loss.
Calculate the win rate percentage and do not forget to format it.

HINT #3
Print the correct output.

 */
public class FootballTournament {
	   public static void main(String[] args) {
		      // Write code here
		        Scanner scanner = new Scanner(System.in);
		        String TeamName = scanner.nextLine();
		        int NumGamesPlayed = Integer.parseInt(scanner.nextLine());
		        
		        int Points = 0;
		        int WinCount = 0;
		        int DrawCount = 0;
		        int LoseCount = 0;
		        double winrate = 0;
		        
		        if (NumGamesPlayed == 0)
		        {
		        	System.out.printf("%s hasn't played any games during this season.", TeamName);
		        }
		        else 
		        {
		        	if (NumGamesPlayed <= 100)
		        	{	
				        for(int i=0; i<NumGamesPlayed; i++)
				        {
				        	//String inputstr = scanner.nextLine();
				        	//char result = inputstr.charAt(0);
				        	char result = scanner.nextLine().charAt(0);
				        	
				        	if (result == 'W')
				        	{
				        		WinCount++;
				        		Points += 3;
				        	}
				        	else if (result == 'D')
				        	{
				        		DrawCount++;
				        		Points += 1;
				        	}
				        	else if (result == 'L')
				        	{
				        		LoseCount++;
				        	}
				        }
		        	}
		        	
		        	winrate = 100*WinCount/NumGamesPlayed;
		        
			        System.out.printf("%s has won %d points during this season.%n", TeamName, Points);
			        System.out.printf("Total stats:%n");
			        System.out.printf("## W: %d%n", WinCount);
			        System.out.printf("## D: %d%n", DrawCount);
			        System.out.printf("## L: %d%n", LoseCount);
			        System.out.printf("Win rate: %.2f%%",winrate);
		        }
	   }
}
