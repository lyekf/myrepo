import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/*
On the first line of the standard input, you will receive an integer "n" - the number of heroes that you can choose for your party.

On the next "n" lines, the heroes will follow with their hit points and mana points separated by empty space in the following format:

"{hero name} {HP} {MP}"

HP stands for hit points and MP for mana points. A hero can have a maximum of 100 HP and 200 MP.

After you have successfully picked your heroes, you can start playing the game.

You will be receiving different commands, each on a new line, separated by " - " (space dash space), until the "End" command is given.

There are several actions that can be performed by the heroes:

"CastSpell - {hero name} - {MP needed} � {spell name}":

If the hero has the required MP, they cast the spell which reduces their MP. Print the following message:

"{hero name} has successfully cast {spell name} and now has {mana points left} MP!"

If the hero is unable to cast the spell, print:

"{hero name} does not have enough MP to cast {spell name}!"

"TakeDamage - {hero name} - {damage} - {attacker}":

Reduce the hero HP by the given damage amount.

If the hero is still alive (their HP is greater than 0) print:

"{hero name} was hit for {damage} HP by {attacker} and now has {current HP} HP left!"

If the hero has died, remove them from your party and print:

"{hero name} has been killed by {attacker}!"

"Recharge - {hero name} - {amount}":

The hero increases their MP.

If a command is given that would bring the MP of the hero above "200", MP is increased so that it reaches the maximum.

Print the following message:

"{hero name} recharged for {amount recovered} MP!"

"Heal - {hero name} - {amount}":

The hero increases his HP.

If a command is given that would bring the HP of the hero above "100", HP is increased so that it reaches the maximum.

Print the following message:

"{hero name} healed for {amount recovered} HP!"

Input
On the first line of the standard input, you will receive an integer "n"

On the next n lines, the heroes themselves will follow with their hit points and mana points separated by empty space in the described format

You will be receiving different commands, each on a new line, separated by " - " (space dash space ), until the "End" command is given

Output
Print all members of your party who are still alive, sorted by their HP in descending order, then by their name in ascending order, in the following format (their HP/MP need to be indented 2 spaces):

"{hero name}
HP: {current HP}
MP: {current MP}
..."


Constraints
The starting HP/MP of the heroes will be valid, 32-bit integers, will never be negative, or exceed the respective limits

The HP/MP amounts in the commands will never be negative

The hero names in the commands will always be valid members of your party

No need to check that explicitly


Example One
//Input 
4
Adela 90 150
SirMullich 70 40
Ivor 1 111
Tyris 94 61
Heal - SirMullich - 50
Recharge - Adela - 100
CastSpell - Tyris - 1000 - Fireball
TakeDamage - Tyris - 99 - Fireball
TakeDamage - Ivor - 3 - Mosquito
End
////////////////////////
 
				
Input										Output
4											SirMullich healed for 30 HP!

Adela 90 150								Adela recharged for 50 MP!

SirMullich 70 40							Tyris does not have enough MP to cast Fireball!

Ivor 1 111									Tyris has been killed by Fireball!

Tyris 94 61									Ivor has been killed by Mosquito!

Heal - SirMullich - 50						SirMullich

Recharge - Adela - 100						HP: 100

CastSpell - Tyris - 1000 - Fireball			MP: 40

TakeDamage - Tyris - 99 - Fireball			Adela

TakeDamage - Ivor - 3 - Mosquito			HP: 90

End											MP: 200

HINT #1
"Heal" - SirMullich healed for 30 HP due to the HP max limit.

HINT #2
"Recharge" - Adela recharged for 50 MP due to the MP max limit.

HINT #3
"CastSpell" - Tyris does not have enough MP to cast the spell.

HINT #4
"TakeDamage" - Tyris's HP is reduced by 99, thus becoming -5, which means that he is dead.

HINT #5
"TakeDamage" - Ivor's HP is now -2, so he is dead too.

HINT #6
After the "End" command we print the remaining living heroes, sorted by their HP in decending order.


Example Two
//Input 
2
Solmyr 85 120
Kyrre 99 50
Heal - Solmyr - 10
Recharge - Solmyr - 50
TakeDamage - Kyrre - 66 - Orc
CastSpell - Kyrre - 15 - ViewEarth
End

///////////////////


Input											Output
2												Solmyr healed for 10 HP!

Solmyr 85 120									Solmyr recharged for 50 MP!

Kyrre 99 50										Kyrre was hit for 66 HP by Orc and now has 33 HP left!

Heal - Solmyr - 10								Kyrre has successfully cast ViewEarth and now has 35 MP!

Recharge - Solmyr - 50							Solmyr

TakeDamage - Kyrre - 66 - Orc					HP: 95

CastSpell - Kyrre - 15 - ViewEarth				MP: 170

End												Kyrre	

												HP: 33

												MP: 35

 */
public class HeroesOfCodeLogicVII {

	
	public static final int MAX_HP = 100;
	public static final int MAX_MP = 200;
	
	public static void main(String[] args) {
		   Scanner scanner = new Scanner(System.in);

		   List<Hero> heroesList = new ArrayList<>();
		   
		   int HeroCount = Integer.parseInt(scanner.nextLine());
		   
		   int hp = 0;
		   int mp = 0;
		   Hero hero = null;
		   Hero existingHero = null;
	       
		   for(int i=0; i<HeroCount; i++){
			   String[] heroInfo = scanner.nextLine().split(" ");
			   String heroName = heroInfo[0];
			   hp = Integer.parseInt(heroInfo[1]);
			   mp = Integer.parseInt(heroInfo[2]);
			   
			   hero = new Hero(heroName, hp, mp);

			   existingHero = getExistingHero(heroName, heroesList);
			   
			   if (existingHero != null){
				   existingHero.setName(heroName);
				   existingHero.sethp(hp);
				   existingHero.setmp(mp);
			   }
			   else{
				   heroesList.add(hero);			   
			   }
			   
			   
		   }
		   
		   
	   
		   String commandItemInput = scanner.nextLine();		//Command - Item
		   while (!commandItemInput.equals("End")){
			   hp = 0;
			   mp = 0;			   
			   String[] commandItem = commandItemInput.split(" - ");

			   String heroname = "";
			   switch(commandItem[0]){	
				   case "CastSpell":	//"CastSpell - {hero name} - {MP needed} � {spell name}"
					   heroname = commandItem[1];
					   int mpNeeded = Integer.parseInt(commandItem[2]);
					   String Spell = commandItem[3];
					   
					   existingHero = getExistingHero(heroname, heroesList);
					   mp = existingHero.getmp();
					   if (mp > mpNeeded){
						   mp -= mpNeeded;
						   existingHero.setmp(mp);
						   
						   System.out.printf("%s has successfully cast %s and now has %d MP!%n", heroname, Spell, mp);
					   }
					   else{
						   System.out.printf("%s does not have enough MP to cast %s!%n", heroname, Spell);
					   }
					   break;
				   case "TakeDamage":	//"TakeDamage - {hero name} - {damage} - {attacker}"
					   heroname = commandItem[1];
					   int damageAmt = Integer.parseInt(commandItem[2]);
					   String Attacker = commandItem[3];
					   
					   existingHero = getExistingHero(heroname, heroesList);
					   hp = existingHero.gethp();
					   hp -= damageAmt;
					   existingHero.sethp(hp);
					   
					   if (hp > 0){
						   System.out.printf("%s was hit for %d HP by %s and now has %d HP left!%n", heroname, damageAmt, Attacker, hp);
					   }
					   else{
						   heroesList.remove(existingHero);
						   System.out.printf("%s has been killed by %s!%n", heroname, Attacker);
					   }
						   
					   break;
				   case "Recharge":		//"Recharge - {hero name} - {amount}"
					   heroname = commandItem[1];
					   int mpToAdd = Integer.parseInt(commandItem[2]);
					   
					   existingHero = getExistingHero(heroname, heroesList);
					   mp = existingHero.getmp();
					   
					   if (mp + mpToAdd > MAX_MP){
						   mpToAdd = MAX_MP - mp;
						   mp = MAX_MP;
					   }
					   else{
						   mp += mpToAdd;
					   }
					   existingHero.setmp(mp);
					   
					   System.out.printf("%s recharged for %s MP!%n", heroname, mpToAdd);		//amount recovered is mpToAdd or final mp ?
					   break;
				   case "Heal":			//"Heal - {hero name} - {amount}"
					   heroname = commandItem[1];
					   int healAmt = Integer.parseInt(commandItem[2]);

					   existingHero = getExistingHero(heroname, heroesList);
					   hp = existingHero.gethp();
					   if(hp + healAmt > MAX_HP){
						   healAmt = MAX_HP - hp;
						   hp = MAX_HP;
						   
					   }
					   else{
						   hp += healAmt;
					   }
					   existingHero.sethp(hp);
					   
					   System.out.printf("%s healed for %s HP!%n", heroname, healAmt);	//amount recovered is healAmt or final hp ?
					   break;
					   
			   }
			   
			   commandItemInput = scanner.nextLine();			   
		   }

		   
		   List<Hero> sortedbyhpheroesList = heroesList.stream()
				   	.sorted(Comparator.comparing(Hero::gethp))	//sort in descending order
					.sorted(Comparator.comparing(Hero::getName).reversed())				   	
					.collect(Collectors.toList());	   
		   
/*		   
		   List<Hero> sortedbyhpheroesList = heroesList.stream()
				   	.sorted(Comparator.comparing(Hero::gethp))	//sort in descending order
					.collect(Collectors.toList());	   
		   
		   List<Hero> sortedbyNamepheroesList = sortedbyhpheroesList.stream()
				   .sorted(Comparator.comparing(Hero::getName).reversed())
					.collect(Collectors.toList());
*/		   
		   
		   
//		   sortedbyNamepheroesList.forEach(e -> {
		   sortedbyhpheroesList.forEach(e -> {
			   System.out.printf("%s%n",e.getName());
			   System.out.printf("HP: %s%n",e.gethp());
			   System.out.printf("MP: %s%n",e.getmp());
			   
		   });
			 
		   
	}   
		   

	
	   private static Hero getExistingHero(String heroName, List<Hero> heroes){
		   for(Hero savedHero : heroes){
			   if (savedHero.getName().equals(heroName)){ 
					   return savedHero;
			   }
		   }
		   
		   return null;
	   		 
	   }

	
	
}


class Hero {

		private String m_Name;
		private int m_hp;
		private int m_mp;
//		 private Map<String, Integer> CityInfo = new LinkedHashMap<>();		
	
		public Hero(String name, int hp, int mp){
			this.m_Name = name;
			this.m_hp = hp;
			this.m_mp = mp;
//			this.CityInfo.put(m_Name, m_hp);

		}		
		
		public String getName(){
			return this.m_Name; 
		}
		
		public int gethp(){
			return this.m_hp; 
		}	
		
		public int getmp(){
			return this.m_mp; 
		}		
		
		public void setName(String name){
			this.m_Name = name; 
		}
		
		public void sethp(int hp){
			this.m_hp = hp; 
		}
				
		public void setmp(int mp){
			this.m_mp = mp; 
		}
		
}