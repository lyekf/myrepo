

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Scanner;


/*
Flower Wreaths
You want to go on a flowers wreath competition but to participate you have to make at least 5 flower wreaths.

You will be given two sequences of integers, representing roses and lilies. You need to start making wreaths knowing that one wreath needs 15 flowers. Your goal is to make at least 5 flower wreaths.
You will start crafting from the last lilies and the first roses. If the sum of their values is equal to 15 � create one wreath and remove them. If the sum is bigger than 15, just decrease the value of the lilies by 2. If the sum is less than 15 you have to store them for later and remove them. You need to stop combining when you have no more roses or lilies. In the end, if you have any stored flowers you should make as many wreaths as you can with them. 
Input
�	On the first line, you will receive the integers representing the lilies, separated by ", ".
�	On the second line, you will receive the integers representing the roses, separated by ", ".
Output
�	Print whether you have succeeded making at least 5 wreaths:
o	"You made it, you are going to the competition with {count of wreaths} wreaths!" 
o	"You didn't make it, you need {wreaths needed} wreaths more!"

Constraints
�	All of the given numbers will be valid integers in the range [0, 120].
�	Don't have situation with negative number.


Examples
Input									Output
10, 15, 2, 7, 9, 13						You made it, you are going to the competition with 5 wreaths!
2, 10, 8, 12, 0, 5
	
Comment
We start with the last lilies (13) and the first roses (2) -> 13 + 2 = 15 -> 15 = 15 So we create one wreath and remove them bouth. 
Next we have 9 + 10 = 19 -> 19 > 15 so we decrease the lilies by 2 -> 7 + 10 = 17 and we decrease the liles by 2 -> 5 + 10 = 15 and we create one more wreath and remove them.
Next, we have 7 + 8 = 15. We create one more wreaht and remove them.
Next, we have  2 + 12 = 14 -> 14 < 15 so we have to store theire sum for later and remove them.
Next, we have 15 + 0 = 15 so we create one more wreath.
And last we have 10 + 5 = 15, we create one more wreath and stop mixing because we don�t have any flowers left.
Now we have a tottal of 5 wreaths and we also have 14 flowers left but we cant create wreath because 14 < 15. 




Input									Output
10, 5, 3, 7, 8							You didn't make, you need 1 wreaths more!
5, 10, 8, 7, 6	


Comment
We start with 8 + 5 = 13 -> 13 < 15 -> we have to store their sum for later and remove them.
Next, we have 7 + 10 = 17 -> we decrease the lilies by 2 -> 5 + 10 = 15 -> 15 = 15 and we create one wreath.
Next, we have 3 + 8 = 11 -> 11 < 15 -> we store their sum for later and remove them.
Next, we have 5 +7 = 12 -> we store their sum for later and remove them.
Next, we have 10 + 6 = 16 -> 16 > 15 we decrease the lilies by 2 -> 8 + 6 = 14 and we store their sum for later and remove them.
We stop crafting because we don�t have any flowers left and we have 1 wreath and 50 stored flowers. We create 3 more wreaths because 3 * 15 = 45 -> 50 � 45 = 5 -> 5 < 15.


 */


public class Module4ExamQn1FlowerWreaths {

	public static void main(String[] args) {
		   Scanner scanner = new Scanner(System.in);
			
		   String[] commandLineInput = scanner.nextLine().split(", ");
		   Integer[] lilies = new Integer[commandLineInput.length]; 
		   for (int i=0; i<commandLineInput.length; i++ ){
			   //lilies[i] = Integer.parseInt(commandLineInput[i]);
			   lilies[i] = Integer.parseInt(commandLineInput[commandLineInput.length-1-i]);
		   }
		   
		   commandLineInput = scanner.nextLine().split(", ");
		   Integer[] roses = new Integer[commandLineInput.length]; 
		   for (int i=0; i<commandLineInput.length; i++ ){
			   roses[i] = Integer.parseInt(commandLineInput[i]);

		   }
		    
		   ArrayDeque<Integer> stackliliesLootBox = new ArrayDeque<>();
		   for(Integer lily : lilies){
			   stackliliesLootBox.offer(lily);
		   }
		   
		   ArrayDeque<Integer> queuerosesLootBox = new ArrayDeque<>();
		   for(Integer rose : roses){
			   queuerosesLootBox.offer(rose);
		   }
		   
		   int flowerWreathCount = 0;
		   int storedflower = 0;
		   while (!stackliliesLootBox.isEmpty() && !queuerosesLootBox.isEmpty()){
			   
			   int stackLilyElement = stackliliesLootBox.peek();
			   int queueRoseElement = queuerosesLootBox.peek();
			   int resultsum = stackLilyElement + queueRoseElement;
			    
			   
			   if (resultsum == 15){
				   flowerWreathCount++;
//				   stackliliesLootBox.pop();		// remove
//				   queuerosesLootBox.poll();		//remove queue element
			   }
			   else if (resultsum > 15){
				   while (resultsum > 15){
					   if (stackLilyElement > 2)
						   stackLilyElement -= 2;
					   	   resultsum = stackLilyElement + queueRoseElement;
				   }
				
				   if (resultsum == 15){
					   flowerWreathCount++;
				   }
				   else{
					 storedflower += resultsum;
				   }
					   
//				   stackliliesLootBox.pop();
//				   queuerosesLootBox.poll();
					   
			   }
			   else{	//resultsum < 15
//				   stackliliesLootBox.pop();		//remove element
//				   queuerosesLootBox.poll();		//remove element	
				   storedflower += resultsum;
			   }
			
			   stackliliesLootBox.pop();		// remove
			   queuerosesLootBox.poll();		//remove queue element

		   }
		   
		   int additionalWreath = storedflower/15;
		   flowerWreathCount += additionalWreath;
		   
		   
		   if (flowerWreathCount >= 5){
			   System.out.printf("You made it, you are going to the competition with %d wreaths!", flowerWreathCount);
		   }
		   else{
			   System.out.printf("You didn't make it, you need %d wreaths more!", 5-flowerWreathCount);
		   }
		   
	}
}


