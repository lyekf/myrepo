import java.util.*;
/*
Description
Input / Constraints
You will receive a journal containing items, separated by ", " (comma and space). After that, until you receive the command "Craft!", you will be receiving different commands.

The commands are split by " - " (space dash space):

"Collect - {item}": Receiving this command, you should add the given item to your inventory

If the item is already in your inventory, you should skip it.

"Drop - {item}": You should remove the item from your inventory, if it is present in the inventory

"Combine Items - {oldItem}:{newItem}": You should check if the old item is present, if so, place the new item after the old one

Otherwise, ignore the command.

"Renew - {item}": If the given item exists, you should change its position and put it at the last position in your inventory

Output
After receiving "Craft!" print the items in your inventory, separated by ", " (comma and space)

Example One
Input								Output
Iron, Wood, Sword					Iron, Sword, Gold

Collect - Gold

Drop - Wood

Craft!


HINT #1
Split the commands and items for each command by the hyphen, surrounded by spaces: " - "

HINT #2
Create a condition that checks if the items' string contains a colon (":"), and splits it.

HINT #3
Loop through each command/item and modify the inventory accordingly.

HINT #4
At the end, print the inventory to the console using the String.join(delimiter, inventory) method.


Example Two
Input								Output
Iron, Sword							Sword, Bow, Iron

Drop - Bronze

Combine Items - Sword:Bow

Renew - Iron

Craft!

 */
public class Invenrory {
	   public static void main(String[] args) {
		   Scanner scanner = new Scanner(System.in);
		
		   String commandLineInput = scanner.nextLine();
		   String[] Items = commandLineInput.split(", ");
		   
			List<String> ItemList = new ArrayList<>();
			for(int i=0; i<Items.length; i++){
				ItemList.add(Items[i]);
			}		   
		   

		   String commandItemInput = scanner.nextLine();		//Command - Item
		   while (!commandItemInput.equals("Craft!")){
			   String[] commandItem = commandItemInput.split(" - ");

			   
			   switch(commandItem[0]){	
				   case "Collect":
					   if (!ItemList.contains(commandItem[1]))
					   {
						   ItemList.add(commandItem[1]);
					   }
					   break;
				   case "Drop":
					   if (ItemList.contains(commandItem[1]))
					   {
						   ItemList.remove(commandItem[1]);
					   }
					   break;
				   case "Combine Items":
					   String[] oldnewItem = commandItem[1].split(":");
					   if (ItemList.contains(oldnewItem[0])){		//old item exist
						   int itemindex = ItemList.indexOf(oldnewItem[0]);
						   ItemList.add(itemindex+1, oldnewItem[1]);	//place new item after old item
					   }
					   break;
				   case "Renew":
					   if (ItemList.contains(commandItem[1])){
						   int itemindex = ItemList.indexOf(commandItem[1]);		//original item index
						   ItemList.add(ItemList.size(), commandItem[1]);			//place it at the end of list
						   ItemList.remove(itemindex);								//remove old item
					   }
					   break;
   
			   }
			   
			   commandItemInput = scanner.nextLine();
		   }
		   
		   System.out.println(String.join(", ", ItemList));
	}
	   
}
