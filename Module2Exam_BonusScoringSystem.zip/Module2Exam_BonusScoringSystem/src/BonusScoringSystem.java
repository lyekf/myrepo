import java.util.*;
/*
Description
Create a program that calculates the bonus points for each student, for a certain course.

On the first line, you are going to receive the number of students for the course.

On the second line, you are going to receive the number of the lectures in the course.

On the third line, you are going to receive the additional bonus for the course.

On the next lines, you will be receiving the number of attendances for each student.

The bonus points are calculated using the following formula:

{total bonus} = {student attendances} / {course lectures} * (5 + {additional bonus})

Find the student with the most bonus points and print their total points along with attendances in the following format:

"Max Bonus: {maxBonusPoints}."
"The student has attended {studentAttendances} lectures."

In the end, round the bonus points up to the next whole number.

Constrains
There will not be students with the same final amount of bonus points

Output
Print the maximum bonus points, rounded up to the nearest whole number, along with the attendance of the given student, in the format described above

Example One
Input									Output
5										Max Bonus: 34.

25										The student has attended 24 lectures.

30

12

19

24

16

20


HINT #1
First, we receive the number of students enrolled in the course - 5.

The total count of the lectures is 25 and the initial bonus is 30.

HINT #2
Then we calculate the bonus of the student with 12 attendances, which is 16.8.

We continue to calculate each student's bonus points.

HINT #3
The one with 24 attendances has the highest bonus - 33.6 (34 rounded), so we print the corresponding message to the console.


Example Two
Input										Output
10											Max Bonus: 18.

30											The student has attended 28 lectures.

14

8

23

27

28

15

17

25

26

5

18



 */
public class BonusScoringSystem {
	   public static void main(String[] args) {
		   Scanner scanner = new Scanner(System.in);
		   
		   //int[] numbers = Arrays.stream(scanner.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();
		   
		   int NumStudents = Integer.parseInt(scanner.nextLine());
		   int NumLectures = Integer.parseInt(scanner.nextLine());
		   double InitialBonus = Double.parseDouble(scanner.nextLine());
		   
		   
		   int[] StudentAttendance = new int[NumStudents];
		   int maxAttendance = 0;
		   int maxAttendanceIndex = 0;
		   for(int i=0; i<NumStudents; i++){
			   StudentAttendance[i] = Integer.parseInt(scanner.nextLine());
			   
			   if (StudentAttendance[i] > maxAttendance)
			   {
				   maxAttendance = StudentAttendance[i];
				   maxAttendanceIndex = StudentAttendance[i];
			   }
		   }

		   double MaxBonusScore = ((InitialBonus + 5) * maxAttendance)/NumLectures;

		   
		   System.out.printf("Max Bonus: %d.%n", Math.round(MaxBonusScore));
		   System.out.printf("The student has attended %d lectures.", maxAttendanceIndex);
		   
		   
		   //				  (5 +   30)				  * 12				  /	25	 		
		   //{total bonus} = (5 + {additional bonus}) * {student attendances} / {course lectures} 
			   
		   
	   }

}
