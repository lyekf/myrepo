import java.util.*;
import java.util.stream.Collectors;

/*
Input 1

Sofia|Bulgaria|1
Varna|Bulgaria|2
London|UK|4
Cambridge|UK|10
Rome|Italy|3
report

Input 2

Sofia|Bulgaria|1000000
report

 */


/* 
public class Module4ExamQn3PopulationCounter {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String input = "";
        LinkedHashMap<String , LinkedHashMap<String, Long>> countriesAndCities = new LinkedHashMap<>();
        LinkedHashMap<String, Long> countriesOnly = new LinkedHashMap<>();
        while(!(input = sc.nextLine()).equals("report")){
            String [] data = input.split("\\|");
            String city = data[0];
            String country = data[1];
            Long population = Long.parseLong(data[2]);
 
            if(!countriesAndCities.containsKey(country)){
                countriesAndCities.put(country,new LinkedHashMap<>());
                countriesOnly.put(country, 0L);
            }
            countriesOnly.put(country,countriesOnly.get(country)+population);
            if(!countriesAndCities.get(country).containsKey(city)){
                countriesAndCities.get(country).put(city,population);
            }
        }
        countriesAndCities.entrySet().stream()
                .sorted((c1,c2)-> countriesOnly.get(c2.getKey()).compareTo(countriesOnly.get(c1.getKey())))
                .forEach(country ->{
                    System.out.format("%s (total population: %d)\n",country.getKey(),countriesOnly.get(country.getKey()));
                    country.getValue().entrySet()
                            .stream().sorted((t1,t2)-> t2.getValue().compareTo(t1.getValue())).forEach(city ->{
                            System.out.format("=>%s: %d\n", city.getKey(),city.getValue());
                    });
        });
    }
}
*/




public class Module4ExamQn3PopulationCounter {
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
	
	
	
		List<Country> CountryList = new ArrayList<>();
		Country country = null;

		String cityName = "";
		String countryName = "";
		long cityPopulation = 0;	//int cityPopulation = 0;
		
		String commandItemInput = scanner.nextLine();		//Command - Item
		
		
		while (!commandItemInput.equals("report")){
			String[] commandItem = commandItemInput.split("\\|");
	 
			cityName = commandItem[0];
			countryName = commandItem[1];
			//cityPopulation = Integer.parseInt(commandItem[2]);
			cityPopulation = Long.parseLong(commandItem[2]);
			
	 
			country = getCountry(countryName, CountryList);
			if (country != null)
			{
				country.addCity(cityName, cityPopulation);
			}
			else{
				country = new Country(cityName, countryName, cityPopulation);
				CountryList.add(country);
			}
	
			
			
			commandItemInput = scanner.nextLine();
	   }
	
		   List<Country> sortedCountryList = CountryList.stream()
				   	.sorted(Comparator.comparing(Country::getTotalPopulation).reversed())
				   //.sorted(Comparator.comparing(Country::getCity()).reversed())
					.collect(Collectors.toList());
		   
		   
		   sortedCountryList.forEach(e -> {
		   				System.out.printf("%s (total population: %d) %n",e.getCountryName(), e.getTotalPopulation());
		   				
		   				//Map<String, Integer> myMap = e.getCity();
		   				Map<String, Long> myMap = e.getCity();
		   				
		   				myMap.entrySet()
		                .stream()
		                .sorted((a,b)->a.getKey().compareTo(b.getKey()))
		                .forEach(entry -> System.out.printf("=>%s: %d%n",entry.getKey(),entry.getValue()) );
		   } );
	}
	
	   private static Country getCountry(String countryName, List<Country> CountryList){
		   for(Country savedCountry : CountryList){
			   if (savedCountry.getCountryName().equals(countryName)){ 
					   return savedCountry;
			   }
		   }
		   return null;
	   
	   }
	   
}
	

 class Country {
	 private String countryName;

	 //private Map<String, Integer> CityInfo = new LinkedHashMap<>();
	 private Map<String, Long> CityInfo = new LinkedHashMap<>();
	 
	 long totalPopulation;	//	 int totalPopulation;
	 

	 
	//public Country(String cityName, String countryName, int cityPopulation){
	 public Country(String cityName, String countryName, long cityPopulation){
		this.countryName = countryName;
		this.CityInfo.put(cityName, cityPopulation);
		this.totalPopulation = cityPopulation;
	}

	//public void addCity(String cityName, int cityPopulation){
	public void addCity(String cityName, long cityPopulation){
		this.CityInfo.put(cityName, cityPopulation);
		this.totalPopulation += cityPopulation;
	}

	
	public String getCountryName(){
		return this.countryName;
	}
	
	//public Map<String, Integer> getCity(){
	public Map<String, Long> getCity(){
		return this.CityInfo;
	}
	
	//public String getCityName(){
//		return this.CityInfo.get(key);
	//}
	
	//public int getTotalPopulation(){
	public long getTotalPopulation(){
//		for(Integer cityPopulation : CityInfo.values()){
//			totalPopulation += cityPopulation;
//		} 
		return totalPopulation;
	}
 }

