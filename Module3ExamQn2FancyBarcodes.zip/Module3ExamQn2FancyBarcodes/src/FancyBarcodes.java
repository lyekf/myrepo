import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/*
Description
Your first task is to determine if the given sequence of characters is a valid barcode or not.

Each line must contain only valid barcodes.

A barcode is valid when:

is surrounded with a "@" followed by one or more "#"

is at least 6 characters long (without the surrounding "@" or "#")

starts with a capital letter

contains only letters (lower and upper case) and digits

ends with a capital letter

Examples of valid barcodes:"@#FreshFisH@#", "@###Brea0D@###", "@##Che46sE@##"

Examples of invalid barcodes: "##InvaliDiteM##", "@InvalidIteM@", "@#Invalid_IteM@#"

Next, you have to determine the product group of the item from the barcode.

The product group is obtained by concatenating all the digits found in the barcode.

If there are no digits present in the barcode, the default product group is "00".

Examples:

"@#FreshFisH@#" -> product group: 00

"@###Brea0D@###" -> product group: 0

"@##Che4s6E@##" -> product group: 46

Input
On the first line, you will be given an integer "n" - the count of barcodes that you will be receiving next.

On the next "n" lines, you will receive different strings.

Output
For each barcode that you process, you need to print a message.

If the barcode is invalid:

"Invalid barcode"

If the barcode is valid:

"Product group: {product group}"

Examples
Input							Output
3								Product group: 00

@#FreshFisH@#					Product group: 0

@###Brea0D@###					Product group: 46

@##Che4s6E@##


Input							Output
6								Product group: 11

@###Val1d1teM@###				Product group: 00

@#ValidIteM@#					Invalid barcode

##InvaliDiteM##					Invalid barcode

@InvalidIteM@					Invalid barcode

@#Invalid_IteM@#				Product group: 00

@#ValiditeM@#



 */
public class FancyBarcodes {
	public static void main(String[] args) {
		   Scanner scanner = new Scanner(System.in);

		   String regex = "@#{1,}[A-Z]{1}[A-Za-z0-9]{4,}[A-Z]{1}@#";
		   Pattern pattern = Pattern.compile(regex);		   
		   
		   int BarcodeCount =  Integer.parseInt(scanner.nextLine());

		   for(int i=0; i<BarcodeCount; i++){
			   String barcode = scanner.nextLine();   

			   
			   Matcher matcher = pattern.matcher(barcode);
			   
			   if (!matcher.find()){
				   System.out.printf("Invalid barcode%n");
			   }
			   else
			   {
				   	String productgrp = "";
				   	int length = barcode.length();
				   	for(int j=0; j<length; j++ ){
				   		if ((barcode.charAt(j) >= '0') && (barcode.charAt(j) <= '9')){
				   			productgrp += barcode.charAt(j); 
				   		}
				   	}
				   	
				   	if (productgrp.equals("")){
				   		productgrp = "00";			//default product group
				   	}
				   	
				   	//now convert product grp string into digit
				   	int productgrpDigit = Integer.parseInt(productgrp);
				   	
				   	System.out.printf("Product group: %s%n",productgrp);
//				   	if (productgrp.equals("00")){
//				   		System.out.printf("Product group: %s%n",productgrp);
//				   	}
//				   	else
//				   	{
//				   		System.out.printf("Product group: %d%n", productgrpDigit);
//				   	}
				   	
			   }
		   }
	}
	
}
