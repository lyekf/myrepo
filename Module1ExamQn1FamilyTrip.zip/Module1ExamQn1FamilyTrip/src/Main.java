import java.util.Scanner;

/*
Description
The Smiths are planning their family trip.

Your task is to create a program that calculates whether their budget will be sufficient knowing how many nights they have planned to stay, what the price per night is and what percentage of their budget must be spent on additional costs.

Keep in mind that if they stay longer than 7 nights the price per night is reduced by 5%.

Input
You will receive 4 lines of input:

The budget that they have - a real number in range[1.00 ... 10000.00]

The number of nights - an integer in range[0 ... 1000]

The price per night - a real number in range[1.00 ... 500.00]

The additional cost percentage - an integer in range[0 ... 100]

Output
The output depends on whether the budget is sufficient or not:

If the budget is sufficient:

"The Smiths will be left with {money left after the trip} dollars after the vacation."

If the budget is insufficient:

"{money needed} dollars needed."

The sum must be formatted to the second digit after the decimal point.

Example
Input											Output
800.50											The Smiths will be left with 24.49 dollars after the vacation.

8

100

2


Input											Output
504.20											111.54 dollars needed.

10

54.20

20

HINT #1
Determine if there will be a discount if the Smiths are staying more than 7 days.
If there's a discount, calculate how much is it and subtract it from the price per night.

HINT #2
Calculate the price for the all the nights and add the additional costs.

HINT #3
Check if their budget is sufficient and print the correct output.
 */
public class Main {
	   public static void main(String[] args) {
		      // Write code here
		        Scanner scanner = new Scanner(System.in);
		        double Budget = Double.parseDouble(scanner.nextLine());
	        	int NumNights = Integer.parseInt(scanner.nextLine());
	        	double PricePerNight = Double.parseDouble(scanner.nextLine());
	        	int AdditionalCostPercent = Integer.parseInt(scanner.nextLine());
	        	
	        	double discount = 0;
	        	double AdditionalCost = 0;
	        	double TotalNightCost = 0;
	        	double TotalCost = 0;
	        	if ((Budget >= 1.00 && Budget <= 10000.00) &&
	        	   	(NumNights >= 0 && NumNights <= 1000) &&
	        	   	(PricePerNight >= 1.00 && PricePerNight <= 500.00) &&
	        	   	(AdditionalCostPercent >= 0 && AdditionalCostPercent < 100))
				{
	        		if 	(NumNights > 7)
	        		{
	        			PricePerNight *= 0.95;
	        		}
	        		
	        		TotalNightCost = PricePerNight * NumNights;
	        		AdditionalCost = Budget*AdditionalCostPercent/100;
	        		TotalCost = TotalNightCost + AdditionalCost;
	        		if (TotalCost <= Budget)
	        		{
	        			double Amtleft = Budget - TotalCost;
	        			System.out.printf("The Smiths will be left with %.2f dollars after the vacation.", Amtleft);
	        		}
	        		else
	        		{
	        			double AmtNeeded = TotalCost - Budget;
	        			System.out.printf("%.2f dollars needed.",AmtNeeded);
	        		}
	        		
	        		
				}
	        	   	
	   }
}
