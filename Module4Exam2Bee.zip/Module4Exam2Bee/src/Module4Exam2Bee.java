
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Scanner;


/*
 * Input 1
5
Bff..
..O..
f.f.f
.....
fffff
right
right
down
left
left
down
down
right
down


Input 2
4
....
.O..
ff..
f.B.
left
left
up
right
up
End
 */
public class Module4Exam2Bee {

	public static void main(String[] args) {
		   Scanner scanner = new Scanner(System.in);
		   
		   int matrixSize = Integer.parseInt(scanner.nextLine());
		   char[][] matrix = new char[matrixSize][matrixSize];
		   
		   int beeRow = 0;
		   int beeCol = 0;
		   
		   
		   for(int row=0; row<matrix.length; row++){
			   char[] elements = scanner.nextLine().toCharArray();
			   for(int col=0; col<matrix[row].length; col++){
				   if (elements[col] == 'B'){
					   beeRow = row;
					   beeCol = col;
				   }
				   
				   matrix[row][col] = elements[col];
			   }
		   }		   
	
		   
		   
		   int pollinatedFlowers = 0;
		   boolean isBeeLost = false;
		   
		   String command = scanner.nextLine();		
		   while (!command.equals("End") && isBeeLost == false){
			   matrix[beeRow][beeCol] = '.';	//write '.' at current bee position before proceeding to handle command
			   
			   switch(command){
				   case "up":
					   if(isInRange(beeRow-1, beeCol, matrix)){
						   beeRow--;
								   
						   if (isStepOnFlower(beeRow, beeCol, matrix)){
							   pollinatedFlowers++;
							   
						   }
						   else if (isStepOnBonus(beeRow, beeCol, matrix)){
							   matrix[beeRow][beeCol] = '.';			//write '.' to the bonus position
							   
							   beeRow--;		//move 1 more step up
							   if (isStepOnFlower(beeRow, beeCol, matrix)){
								   pollinatedFlowers++;
								   
							   }
						   }
						   
						   matrix[beeRow][beeCol] = 'B';						   
					   }
					   else{	//out of range
						   isBeeLost = true;
					   }
					   
					   
					   break;
				   case "down":
					   if(isInRange(beeRow+1, beeCol, matrix)){
						   beeRow++;
								   
						   if (isStepOnFlower(beeRow, beeCol, matrix)){
							   pollinatedFlowers++;
							   
						   }
						   else if (isStepOnBonus(beeRow, beeCol, matrix)){
							   matrix[beeRow][beeCol] = '.';			//write '.' to the bonus position
							   
							   beeRow++;		//move 1 more step down
							   if (isStepOnFlower(beeRow, beeCol, matrix)){
								   pollinatedFlowers++;
								   
							   }
						   }

						   matrix[beeRow][beeCol] = 'B';						   
					   }
					   else{	//out of range
						   isBeeLost = true;
					   }
					   
					   break;
				   case	"left":
					   if(isInRange(beeRow, beeCol-1, matrix)){
						   beeCol--;
								   
						   if (isStepOnFlower(beeRow, beeCol, matrix)){
							   pollinatedFlowers++;
							   
						   }
						   else if (isStepOnBonus(beeRow, beeCol, matrix)){
							   matrix[beeRow][beeCol] = '.';			//write '.' to the bonus position
							   
							   beeCol--;		//move 1 more step left
							   if (isStepOnFlower(beeRow, beeCol, matrix)){
								   pollinatedFlowers++;
								   
							   }
						   }
						   
						   matrix[beeRow][beeCol] = 'B';						   
					   }
					   else{	//out of range
						   isBeeLost = true;
					   }
					   
					   break;
				   case	"right":
					   if(isInRange(beeRow, beeCol+1, matrix)){
						   beeCol++;
								   
						   if (isStepOnFlower(beeRow, beeCol, matrix)){
							   pollinatedFlowers++;
							   
						   }
						   else if (isStepOnBonus(beeRow, beeCol, matrix)){
							   matrix[beeRow][beeCol] = '.';			//write '.' to the bonus position
							   
							   beeCol++;		//move 1 more step right
							   if (isStepOnFlower(beeRow, beeCol, matrix)){
								   pollinatedFlowers++;
								   
							   }
						   }
						   
						   matrix[beeRow][beeCol] = 'B';						   
					   }
					   else{	//out of range
						   isBeeLost = true;
					   }					   
					   break;
			   }
			   if (isBeeLost == false){
				   command = scanner.nextLine();
			   }
		   }
		   
		   if (isBeeLost == true){
			   System.out.println("The bee got lost!");
		   }
		   if (pollinatedFlowers < 5){
			   System.out.printf("The bee couldn't pollinate the flowers, she needed %d flowers more%n", (5-pollinatedFlowers));
		   }
		   else{
			   System.out.printf("Great job, the bee manage to pollinate %d flowers!%n", pollinatedFlowers);
		   }
		   printMatrix(matrix);

	}
	
	private static void printMatrix(char[][] matrix){
		for (int row=0; row<matrix.length; row++){
			for (int col=0; col<matrix[row].length; col++){
				System.out.print(matrix[row][col]);
			}
			System.out.println();
		}
	}
	
	private static boolean isInRange(int beeRow, int beeCol, char[][] matrix){
		return beeRow >= 0 && beeRow < matrix.length && beeCol >= 0 && beeCol < matrix[beeRow].length;
	}		   
	
	private static boolean isStepOnFlower(int beeRow, int beeCol, char[][] matrix){
		return matrix[beeRow][beeCol] == 'f';
	}
	
	private static boolean isStepOnBonus(int beeRow, int beeCol, char[][] matrix){
		return matrix[beeRow][beeCol] == 'O';
	}

}
