import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*
Description
The first line of the input will be your raw activation key. It will consist of letters and numbers only.

After that, until the "Generate" command is given, you will be receiving strings with instructions for different operations that need to be performed upon the raw activation key.

There are several types of instructions, split by >>>:

"Contains>>>{substring}" - Checks if the raw activation key contains the given substring

if it does, print: "{raw activation key} contains {substring}"

if not, print: "Substring not found!"

"Flip>>>Upper/Lower>>>{startIndex}>>>{endIndex}" - Changes the substring between the given indices (the end index is exclusive) to upper or lower case

All given indexes will be valid.

Prints the activation key.

"Slice>>>{startIndex}>>>{endIndex}"

Deletes the characters between the start and end indices (end index is exclusive).

Both indices will be valid.

Prints the activation key.

Input
The first line of the input will be a string and it will consist of letters and numbers only.

After the first line, until the "Generate" command is given, you will be receiving strings.

Output
After the "Generate" command is received, print:

"Your activation key is: {activation key}"


Examples
Input												Output
abcdefghijklmnopqrstuvwxyz							abghijklmnopqrstuvwxyz

Slice>>>2>>>6										abgHIJKLMNOPQRstuvwxyz

Flip>>>Upper>>>3>>>14								abgHIjkLMNOPQRstuvwxyz

Flip>>>Lower>>>5>>>7								Substring not found!

Contains>>>def										Substring not found!

Contains>>>deF										Your activation key is: abgHIjkLMNOPQRstuvwxyz

Generate



HINT #1
The first command is Slice>>2>>6

We remove the characters between index 2 and 6(not included) - cdef

abcdefghijklmnopqrstuvwxyz -> "abghijklmnopqrstuvwxyz"

HINT #2
Second comes Flip>>>Upper>>>3>>>14

We toggle the characters between index 3 and 14(not included) to uppercase - hijklmnopqr

abghijklmnopqrstuvwxyz -> abgHIJKLMNOPQRstuvwxyz

HINT #3
The third command is Flip>>>Lower>>>5>>>7

abgHIJKLMNOPQRstuvwxyz -> abgHIjkLMNOPQRstuvwxyz

HINT #4
The next command is Contains>>>def

"abgHIjkLMNOPQRstuvwxyz" does not contain "def", so we print:

"Substring not found!"

HINT #5
The last command is Contains>>>deF:

"abgHIjkLMNOPQRstuvwxyz" does not contain "deF"

HINT #6
The final activation key is "abgHIjkLMNOPQRstuvwxyz"


Input											Output
134softsf5ftuni2020rockz42						134sf5ftuni2020rockz42

Slice>>>3>>>7									Substring not found!

Contains>>>-rock								Substring not found!

Contains>>>-uni-								Substring not found!

Contains>>>-rocks								134SF5FTuni2020rockz42

Flip>>>Upper>>>2>>>8							134SF5ftuni2020rockz42

Flip>>>Lower>>>5>>>11							Your activation key is: 134SF5ftuni2020rockz42

Generate





 */
public class ActivationKeys {
	public static void main(String[] args) {
		   Scanner scanner = new Scanner(System.in);
		   String RawActivationKey = scanner.nextLine();
		   String CurrentActivationKey = RawActivationKey; 
		   
		   String inputCommand = scanner.nextLine();
		   
		   String regex = "[A-Za-z0-9]+";		
		   
		   Pattern pattern = Pattern.compile(regex);
		   Matcher matcher = pattern.matcher(RawActivationKey);		   
		   
		   
			   while(!inputCommand.equals("Generate")){
				   
					   String[] tokens = inputCommand.split("\\>\\>\\>");
					   String commmand = tokens[0];
					   
					   switch(commmand){
					   	case "Contains":
					   		String substr = tokens[1];
							   if (CurrentActivationKey.contains(substr)){
								   System.out.printf("%s contains %s%n", CurrentActivationKey, substr);
							   }
							   else{
								   System.out.printf("Substring not found!%n");
							   }
					   		break;
					   	case "Flip":
					   		String UpperOrLower = tokens[1];
					   		int startindex = Integer.parseInt(tokens[2]);
					   		int endindex = Integer.parseInt(tokens[3]);

					   			String substrToConvert = "";
					   			if (UpperOrLower.equals("Upper")){
					   				substrToConvert = CurrentActivationKey.substring(startindex, endindex).toUpperCase();	
					   			}
					   			else{
					   				substrToConvert = CurrentActivationKey.substring(startindex, endindex).toLowerCase();
					   			}
			
								   StringBuilder tempPass = new StringBuilder();
								   
								   for(int i = 0; i < startindex; i++){
									   tempPass = tempPass.append(CurrentActivationKey.charAt(i));
								   }
								   
								   tempPass = tempPass.append(substrToConvert);
								   
								   for(int i = endindex; i < CurrentActivationKey.length(); i++){
									   tempPass = tempPass.append(CurrentActivationKey.charAt(i));
								   }
								   
								   CurrentActivationKey = tempPass.toString();
								   
								   System.out.printf("%s%n", CurrentActivationKey);
								
					   		break;
					   	case "Slice":
					   			startindex = Integer.parseInt(tokens[1]);
					   			endindex = Integer.parseInt(tokens[2]);
					   					   		
							   String firstPart = CurrentActivationKey.substring(0, startindex);
							   String secondPart = CurrentActivationKey.substring(endindex);
							   
							   CurrentActivationKey = firstPart + secondPart;
							   
							   System.out.printf("%s%n", CurrentActivationKey);
					   		break;
					   		
					   }
				   		inputCommand = scanner.nextLine();
				   
				   }
//			   		if (matcher.find()){
			   			System.out.printf("Your activation key is: %s%n", CurrentActivationKey);
//			   		}
//			   		else{
//			   			System.out.printf("Your activation key is: %s%n", RawActivationKey);
//			   		}
			   				
		   
	}

}
